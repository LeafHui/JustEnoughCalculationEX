package me.towdium.jecalculation;

import dev.architectury.registry.registries.DeferredRegister;
import dev.architectury.registry.registries.RegistrySupplier;
import me.towdium.jecalculation.gui.JecaGui;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import javax.annotation.ParametersAreNonnullByDefault;

/**
 * Author: towdium
 * Date:   8/10/17.
 */
@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
public class JecaItem extends Item {

    public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(JustEnoughCalculation.MODID, Registries.f_256913_);

    public static RegistrySupplier<JecaItem> CRAFT = register("craft");
    public static RegistrySupplier<JecaItem> MATH = register("math");

    String key;

    private JecaItem(String name) {
        super(new Item.Properties().m_41487_(1).arch$tab(CreativeModeTabs.f_256869_));
        key = "jecalculation.item.calculator_" + name;
    }

    public static void register() {
        REGISTRY.register();
    }

    private static RegistrySupplier<JecaItem> register(String name) {
        return REGISTRY.register(new ResourceLocation(JustEnoughCalculation.MODID, "item_calculator_" + name), () -> new JecaItem(name));
    }

    @Override
    public String m_5524_() {
        return key;
    }

    @Override
    public InteractionResultHolder<ItemStack> m_7203_(Level worldIn, Player playerIn, InteractionHand handIn) {
        ItemStack is = playerIn.m_21120_(handIn);
        Inventory inv = playerIn.m_150109_();
        if (playerIn.m_6144_()) {
            ItemStack neu = new ItemStack(is.m_41720_() == CRAFT.get() ? MATH.get() : CRAFT.get());
            neu.m_41751_(is.m_41783_());
            if (handIn == InteractionHand.MAIN_HAND) inv.m_6836_(inv.f_35977_, neu);
            else if (handIn == InteractionHand.OFF_HAND) inv.f_35976_.set(0, neu);
        } else if (worldIn.f_46443_) {
            if (is.m_41720_() == CRAFT.get()) JecaGui.openGuiCraft(is, inv.f_35977_);
            else if (is.m_41720_() == MATH.get()) JecaGui.openGuiMath(is, inv.f_35977_);
            else throw new RuntimeException("Internal error");
        }
        return InteractionResultHolder.m_19090_(is);
    }
}

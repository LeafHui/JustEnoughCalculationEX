package me.towdium.jecalculation.network.packets;

import dev.architectury.networking.NetworkManager;
import me.towdium.jecalculation.JecaItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.util.Objects;
import java.util.function.Supplier;


public class PCalculator {

    ItemStack stack;
    int slot;

    public PCalculator(FriendlyByteBuf buf) {
        stack = buf.m_130267_();
        slot = buf.readInt();
    }

    public PCalculator(ItemStack stack, int slot) {
        this.stack = stack;
        this.slot = slot;
    }

    public void write(FriendlyByteBuf buf) {
        buf.m_130055_(stack);
        buf.writeInt(slot);
    }

    public void handle(Supplier<NetworkManager.PacketContext> ctx) {
        ctx.get().queue(() -> {
            Inventory inventory = Objects.requireNonNull(ctx.get().getPlayer()).m_150109_();
            ItemStack calculator = inventory.m_8020_(slot);
            if (!calculator.m_41619_() && calculator.m_41720_() instanceof JecaItem) {
                inventory.m_6836_(slot, stack);
                return;
            }
            calculator = inventory.f_35976_.get(0);
            if (!calculator.m_41619_() && calculator.m_41720_() instanceof JecaItem) {
                inventory.f_35976_.set(0, stack);
            }
        });
    }
}
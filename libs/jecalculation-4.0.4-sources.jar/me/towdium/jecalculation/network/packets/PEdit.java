package me.towdium.jecalculation.network.packets;

import dev.architectury.networking.NetworkManager;
import me.towdium.jecalculation.data.structure.Recipe;
import me.towdium.jecalculation.utils.Utilities;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;

import javax.annotation.Nullable;
import java.util.Objects;
import java.util.function.Supplier;

public class PEdit {
    static final String KEY_OLD = "old";
    static final String KEY_NEW = "new";
    static final String KEY_INDEX = "index";
    static final String KEY_RECIPE = "recipe";

    String old, neu;
    int index;
    Recipe recipe;

    public PEdit() {
    }

    // set recipe: Y Y/null Y Y
    // rename group: Y Y -1 null
    // add recipe: Y null -1 Y
    // remove recipe: Y null Y null
    // remove group: Y null -1 null
    public PEdit(String neu, @Nullable String old, int index, @Nullable Recipe recipe) {
        this.neu = neu;
        this.old = old;
        this.index = index;
        this.recipe = recipe;
    }

    public PEdit(FriendlyByteBuf buf) {
        CompoundTag tag = buf.m_130260_();
        tag = tag == null ? new CompoundTag() : tag;
        old = tag.m_128441_(KEY_OLD) ? tag.m_128461_(KEY_OLD) : null;
        neu = tag.m_128461_(KEY_NEW);
        index = tag.m_128451_(KEY_INDEX);
        recipe = tag.m_128441_(KEY_RECIPE) ? new Recipe(tag.m_128469_(KEY_RECIPE)) : null;
    }

    public void write(FriendlyByteBuf buf) {
        CompoundTag tag = new CompoundTag();
        if (old != null) tag.m_128359_(KEY_OLD, old);
        tag.m_128359_(KEY_NEW, neu);
        tag.m_128405_(KEY_INDEX, index);
        if (recipe != null) tag.m_128365_(KEY_RECIPE, recipe.serialize());
        buf.m_130079_(tag);
    }

    public void handle(Supplier<NetworkManager.PacketContext> ctx) {
        ctx.get().queue(() -> {
            Utilities.getRecord(Objects.requireNonNull(ctx.get().getPlayer())).recipes
                    .modify(neu, old, index, recipe);
            Utilities.getRecord(Objects.requireNonNull(ctx.get().getPlayer())).last = old;
        });
    }
}

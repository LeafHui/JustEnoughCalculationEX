package me.towdium.jecalculation.gui.widgets;

import me.towdium.jecalculation.gui.JecaGui;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import javax.annotation.ParametersAreNonnullByDefault;

/**
 * Author: towdium
 * Date:   17-8-18.
 */
@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@Environment(EnvType.CLIENT)
public class WTextField implements IWidget {
    public ListenerAction<? super WTextField> listener;
    protected int xPos, yPos, xSize;
    EditBox textField;
    public static final int HEIGHT = 20;

    public WTextField(int xPos, int yPos, int xSize) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.xSize = xSize;
        textField = new EditBox(Minecraft.m_91087_().f_91062_, xPos + 1, yPos + 1, xSize - 2, 18, Component.m_237113_("WIP"));
    }

    @Override
    public void onMouseFocused(JecaGui gui, int xMouse, int yMouse, int button) {
        textField.m_6375_(xMouse, yMouse, button);
    }

    @Override
    public void onTick(JecaGui gui) {
        textField.m_94120_();
    }

    @Override
    public boolean onMouseClicked(JecaGui gui, int xMouse, int yMouse, int button) {
        textField.m_93692_(textField.m_5953_(xMouse, yMouse));
        if (textField.m_93696_() && button == 1) {
            textField.m_94144_("");
            notifyLsnr();
            return true;
        } else return false;
    }

    @Override
    public boolean onDraw(JecaGui gui, int xMouse, int yMouse) {
        textField.m_87963_(gui.getGraphics(), xPos, yPos, 0);
        return false;
    }

    @Override
    public boolean onKeyPressed(JecaGui gui, int key, int modifier) {
        boolean ret = textField.m_7933_(key, GLFW.glfwGetKeyScancode(key), modifier);
        if (ret) notifyLsnr();
        return textField.m_93696_() && textField.m_94213_() && key != 256;
    }

    @Override
    public boolean onKeyReleased(JecaGui gui, int key, int modifier) {
        textField.m_7920_(key, GLFW.glfwGetKeyScancode(key), modifier);
        return false;
    }

    @Override
    public boolean onChar(JecaGui gui, char ch, int modifier) {
        boolean ret = textField.m_5534_(ch, modifier);
        if (ret) notifyLsnr();
        return ret;
    }

    public String getText() {
        return textField.m_94155_();
    }

    public WTextField setText(String s) {
        textField.m_94144_(s);
        return this;
    }

    @SuppressWarnings("UnusedReturnValue")
    public WTextField setListener(ListenerAction<? super WTextField> listener) {
        this.listener = listener;
        return this;
    }

    public WTextField setColor(int color) {
        textField.m_94202_(color);
        return this;
    }

    protected void notifyLsnr() {
        if (listener != null) listener.invoke(this);
    }
}

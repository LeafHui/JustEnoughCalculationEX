package me.towdium.jecalculation.data.label.labels;

import dev.architectury.fluid.FluidStack;
import me.towdium.jecalculation.utils.Utilities;
import me.towdium.jecalculation.utils.wrappers.Pair;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.material.Fluid;

import java.util.Collection;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

public interface Context<T> {
    LStack<T> create(T t);

    Stream<Pair<TagKey<T>, Stream<T>>> tags();

    Registry<T> registry();

    LTag<T> create(TagKey<T> rl);

    LTag<T> create(TagKey<T> rl, long amount);

    default Collection<TagKey<T>> discover(LStack<T> s) {
        return tags()
                .filter(pair -> pair.getTwo().anyMatch(t -> Objects.equals(t, s.get())))
                .map(Pair::getOne)
                .toList();
    }

    default Stream<LStack<T>> discover(TagKey<T> tag) {
        return tags()
                .filter(pair -> Utilities.equals(pair.getOne(), tag))
                .flatMap(Pair::getTwo)
                .map(this::create);
    }

    Context<Item> ITEM = new Context<>() {
        @Override
        public LStack<Item> create(Item item) {
            return new LItemStack(new ItemStack(item));
        }

        @Override
        public Registry<Item> registry() {
            return BuiltInRegistries.f_257033_;
        }

        @Override
        public Stream<Pair<TagKey<Item>, Stream<Item>>> tags() {
            return Utilities.getTags(BuiltInRegistries.f_257033_);
        }


        @Override
        public LTag<Item> create(TagKey<Item> rl) {
            return new LItemTag(rl);
        }

        @Override
        public LTag<Item> create(TagKey<Item> rl, long amount) {
            return new LItemTag(rl, amount);
        }
    };
    Context<Fluid> FLUID = new Context<>() {
        @Override
        public LStack<Fluid> create(Fluid fluid) {
            return new LFluidStack(FluidStack.create(fluid, 1000));
        }

        @Override
        public Registry<Fluid> registry() {
            return BuiltInRegistries.f_257020_;
        }

        @Override
        public Stream<Pair<TagKey<Fluid>, Stream<Fluid>>> tags() {
            return Utilities.getTags(BuiltInRegistries.f_257020_);
        }


        @Override
        public LTag<Fluid> create(TagKey<Fluid> rl) {
            return new LFluidTag(rl);
        }

        @Override
        public LTag<Fluid> create(TagKey<Fluid> rl, long amount) {
            return new LFluidTag(rl, amount);
        }
    };

    default boolean matches(TagKey<?> tag, LStack<?> s) {
        if (s.getContext() != this)
            return false;

        Optional<HolderSet.Named<T>> tagEntry = registry().m_203431_((TagKey<T>) tag);
        if (tagEntry.isEmpty())
            return false;

        HolderSet.Named<T> holderSet = tagEntry.get();
        return holderSet.m_203614_()
                .map(Holder::m_203334_)
                .anyMatch(t -> t.equals(s.get()));
    }
}

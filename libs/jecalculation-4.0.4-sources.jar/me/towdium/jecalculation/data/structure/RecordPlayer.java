package me.towdium.jecalculation.data.structure;

import net.minecraft.nbt.CompoundTag;

/**
 * Author: Towdium
 * Date: 19-1-21
 */
public class RecordPlayer implements IRecord {
    public static final String KEY_RECIPES = "recipes";
    public static final String KEY_LAST = "last";

    public Recipes recipes;
    public String last;  // last group edited

    public RecordPlayer() {
        recipes = new Recipes();
    }

    public RecordPlayer(CompoundTag nbt) {
        this();
        deserialize(nbt);
    }

    public void deserialize(CompoundTag tag) {
        recipes.deserialize(tag.m_128469_(KEY_RECIPES));
        last = tag.m_128461_(KEY_LAST);
    }

    @Override
    public CompoundTag serialize() {
        CompoundTag ret = new CompoundTag();
        if (last != null) ret.m_128359_(KEY_LAST, last);
        ret.m_128365_(KEY_RECIPES, recipes.serialize());
        return ret;
    }
}
